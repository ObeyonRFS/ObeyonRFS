import argparse
import os
import RFS
import RFS.core
# import RFS.comm_type.msgs
# import RFS.comm_type.srvs
from pathlib import Path
import glob

def main():

    parser = argparse.ArgumentParser(description='RFS command line interface')
    subparsers = parser.add_subparsers(title='Command', dest='command',required=True)

    if subparsers:
        version_cmd = subparsers.add_parser('version', help='Show RFS version')
    if subparsers:
        core_arg = subparsers.add_parser('core', help='RFS core managing command')
        core_manging_cmd = core_arg.add_subparsers(title='RFS core managing command', dest='core_action')
        core_manging_cmd.add_parser('start', help='Start RFS core')
        core_manging_cmd.add_parser('stop', help='Stop RFS core')
    if subparsers:
        ws_cmd = subparsers.add_parser('workspace', help='RFS workspace managing command')
        ws_managing_cmd = ws_cmd.add_subparsers(title='RFS workspace managing command', dest='ws_action')
        ws_managing_cmd.add_parser('create', help='Create RFS workspace')
        ws_managing_cmd.add_parser('link', help='Link RFS workspace to global')
        ws_managing_cmd.add_parser('unlink', help='Unlink RFS workspace from global')
    if subparsers:
        launch_cmd = subparsers.add_parser('launch', help='Launch the set of RFS commands')
        launch_cmd.add_argument('launch_file_location',type=str, help='Location of the launch file (.launch.py)')


    args = parser.parse_args()
    # print(args)
    if args.command == 'version':
        print('RFS version: '+RFS.__version__)
    elif args.command == 'core':
        if args.core_action == 'start':
            print('Starting RFS core')
        elif args.core_action == 'stop':
            print('Stopping RFS core')
    elif args.command == 'workspace':
        if args.include_ws_action == 'create':
            print('Creating RFS workspace')
            workspace_name = input('Enter the name of created workspace: ')
            workspace_format_path = Path(RFS.__path__)/'{workspace_format}'
            created_workspace_path = Path(workspace_name)
            for format_file in glob.glob(f'{workspace_format_path}/**', recursive=True):
                #copy all formatted and formatted file

                print(format_file)
        elif args.include_ws_action == 'link':
            #pip install -e .
            print('Linking RFS workspace to global')
        elif args.include_ws_action == 'unlink':
            print('Unlinking RFS workspace from global')
    elif args.command == 'launch':
        print('Launching the set of RFS commands')
        launch_file_location=Path(args.launch_file_location)
        print(launch_file_location)

    else:
        print('Command not found')