#launch service and client
#launch subscriber and publisher