from RFS.msgs import MsgType

class SimpleMsg3(MsgType):
    data : str = "Hello, World!"