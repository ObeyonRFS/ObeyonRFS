import RFS

from RFS.RFS_Socket import RFS_CommObjServerSocket
from RFS.RFS_Socket import RFS_CommObjToCoreClientSocket


class CommObj():#communication object
    def __init__(self):
        self.host = RFS.get_current_device_ip()
        self.port = RFS.generate_random_port(RFS.get_current_device_ip())
        print(f"host: {self.host}, port: {self.port}")
        self.server_socket = RFS_CommObjServerSocket(self.host, self.port)
        self.client_to_core_socket = RFS_CommObjToCoreClientSocket()
    def obtain_json(self):
        return self.server_socket.analyze_stocked_msg()