def main():
    print("Hello from simple_example_pkg")