def main():
    print("Hello from {workspace_format}")