from RFS.msgs import MsgType

class SimpleMsg2(MsgType):
    data : str = "Hello, World!"